import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DuedatecellrendererComponent } from './duedatecellrenderer.component';

describe('DuedatecellrendererComponent', () => {
  let component: DuedatecellrendererComponent;
  let fixture: ComponentFixture<DuedatecellrendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DuedatecellrendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DuedatecellrendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should check past due', () => {
    component.isPastDue = true;
    fixture.detectChanges();
    expect(submitEl.nativeElement.disabled).toBeTruthy();
  });
 
});
