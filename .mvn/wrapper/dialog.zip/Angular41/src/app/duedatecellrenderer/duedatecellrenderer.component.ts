import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-duedatecellrenderer',
  templateUrl: './duedatecellrenderer.component.html',
  styleUrls: ['./duedatecellrenderer.component.css']
})
export class DuedatecellrendererComponent implements OnInit {

  dueDate: string;
  isPastDue: boolean;
  constructor() {

  }

  ngOnInit() {
    this.isPastDue = false;
  }

  checkClass(): any {
    return {
      'warn': this.isPastDue
    };
  }
}
