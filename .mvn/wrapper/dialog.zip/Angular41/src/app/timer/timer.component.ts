import {Component, OnInit} from '@angular/core';
import {Observable, Subscription} from 'rxjs/Rx';
import {timer} from 'rxjs/observable/timer';
import 'rxjs/add/operator/finally';
import 'rxjs/add/operator/takeUntil';
import 'rxjs/add/operator/map';
import {MatDialog, MatDialogRef} from '@angular/material';
import {PromptdialogComponent} from '../promptdialog/promptdialog.component';

@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.css']
})
export class TimerComponent implements OnInit {
  timerc: any;
  ticks = 0;
  result = 'CLOSED';
  interval = 1000;

  minutesDisplay = 0;
  hoursDisplay = 0;
  secondsDisplay = 0;
  sessionTimeout = 10;
  dialogRef: any;
  sub: Subscription;
  constructor(public dialog: MatDialog) {}
  ngOnInit() {
    this.startCountdownTimer();
  }

  private startTimer() {
    const duration = 10 * 1000;
    this.timerc = timer(1, this.interval);
    this.sub = this.timerc.subscribe(
      t => {
        this.ticks = t;
        if (this.ticks >= this.sessionTimeout) {
          this.openSessionDialog();
        }
        this.showCountDown();
      }
    );
  }
  private startCountdownTimer() {
    const interval = 1000;
    const duration = 10 * 1000;
    const stream$ = Observable.timer(0, interval)
      .finally(() => {
        this.openSessionDialog();
        console.log('All done!');
      })
      .takeUntil(Observable.timer(duration + interval))
      .map(value => duration - value * interval);
    this.sub = stream$.subscribe(t => {
      this.ticks = t;
      this.showCountDown();
    });
  }
  openSessionDialog() {
    if (this.result === 'CLOSED') {
      this.result = 'OPEN';
      this.dialogRef = this.dialog.open(PromptdialogComponent);

      this.dialogRef.afterClosed()
        .subscribe(selection => {
          if (selection) {
            this.result = selection;
            this.ticks = 0;
            this.timerc = null;
            this.sub.unsubscribe();
            if (this.result === 'YES') {
              this.startCountdownTimer();
            } else {

            }
          } else {
            // User clicked 'Cancel' or clicked outside the dialog
          }
          this.result = 'CLOSED';
        });
    }
  }
  transform(value: number): string {
    const hours: number = Math.floor(value / 3600);
    const minutes: number = Math.floor((value % 3600) / 60);
    return ('00' + hours).slice(-2) + ':' + ('00' + minutes).slice(-2) + ':' + ('00' + Math.floor(value - minutes * 60)).slice(-2);
  }
  private showCountDown() {
    this.secondsDisplay = this.getSeconds(this.ticks);
    this.minutesDisplay = this.getMinutes(this.ticks);
    this.hoursDisplay = this.getHours(this.ticks);
  }
  private getSeconds(ticks: number) {
    return this.pad(ticks % 60);
  }

  private getMinutes(ticks: number) {
    return this.pad((Math.floor(ticks / 60)) % 60);
  }

  private getHours(ticks: number) {
    return this.pad(Math.floor((ticks / 60) / 60));
  }

  private pad(digit: any) {
    return digit <= 9 ? '0' + digit : digit;
  }
}
