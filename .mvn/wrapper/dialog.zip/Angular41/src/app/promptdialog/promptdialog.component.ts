import {Component, OnInit} from '@angular/core';

import {MatDialogRef} from '@angular/material';

@Component({
  selector: 'app-promptdialog',
  templateUrl: './promptdialog.component.html',
  styleUrls: ['./promptdialog.component.css']
})
export class PromptdialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<PromptdialogComponent>) {}

  confirmSelection(res: string) {
    this.dialogRef.close(res);
  }

  ngOnInit() {
  }

}
