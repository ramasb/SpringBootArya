package balaji.nila.arya.soap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("balaji.nila.arya")
public class SpringSoapApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSoapApplication.class, args);
	}
}
