package balaji.nila.arya.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import balaji.nila.arya.client.WeatherClient;

@RestController
public class WeatherController {

	@Autowired
	private WeatherClient weatherClient;

	@RequestMapping("/getweather")
	public String getWeather(@RequestParam(value = "countryname", defaultValue = "India") String countryname) {
		return weatherClient.getCities(countryname);
	}	
}
	